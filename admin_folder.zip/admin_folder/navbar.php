<!-- Sidebar -->

 
<nav class="navbar navbar-expand-md bg-dark navbar-dark fixed-top" style="margin-bottom:5%;">
  <!-- Brand -->
  <a class="navbar-brand" href="#">SRI JOTHI VIGNEESH JEWELLERS</a>

  <!-- Toggler/collapsibe Button -->
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>

  <!-- Navbar links -->
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="index.php"><i class="fa fa-gem"></i> Products</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="viewShopDetails.php"><i class="fa fa-store"></i> Shop Details</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="viewContacts.php"><i class="fa fa-phone-alt"></i> Contact</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="viewQueries.php"><i class="fa fa-list-alt"></i> Queries</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="viewAdmin.php"><i class="fa fa-user-cog"></i> Admin</a>
      </li>
    </ul>
    <ul class="nav navbar-nav ml-auto">
    <li class="nav-item">
        <a class="nav-link" href="#"><form method="post" action="logout.php"><button type="submit" class="btn" name="btnLogout" style="background-color: inherit; color:aliceblue;border:1px dashed aliceblue;border-radius:2px;">Logout</button></form></a>
      </li>
    </ul>
    
  </div>
</nav>
<br>
<br>


