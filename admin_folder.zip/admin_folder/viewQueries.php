<?php
            include "./headerpage.php";
?><?php session_start();
if(empty($_SESSION['id'])):
    header('Location:login.php');
endif;
?>
<?php 
if(isset($_SESSION['status'])){
  
    ?>
    <div class="alert alert-success alert-dismissible" style="width:500px;margin: 0 auto;">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Success!!!</strong>  <?php echo $_SESSION['status'];?>
  </div>
    
<?php
unset($_SESSION['status']);

}


?>
<style>
@media screen and (max-width: 600px) {
  div.scrollableq1 {
    width: 100%;
    height:100%;
    margin: 0;
    padding: 10px;
    overflow: auto;
    
  
  }

}
div.scrollableq2 {
    width: 200px;
    height: 100px;
    margin: 0;
    padding: 10px;
    overflow: auto;
}
  
  
</style>
<div style="margin-left:2% ;margin-right:2%;">
<h2>Recieved Queries</h2>
<div class="scrollableq1">
  <table class="table">
    <thead>
      <tr>
        <th class="text-center">S.No.</th>
        <th class="text-center">Name</th>
        <th class="text-center">Email</th> 
        <th class="text-center">Address</th>
        <th class="text-center">Phone</th>
        <th class="text-center">Query</th> 
        
        <th class="text-center">Action</th>
      </tr>
    </thead>
    <?php
      $conn= mysqli_connect("localhost","root","","myproject");
      $sql="SELECT * from customer_queries";
      $result=$conn-> query($sql);
      $count=1;
      if ($result-> num_rows > 0){
        while ($row=$result-> fetch_assoc()) {
    ?>
    <tr>
      <td><?=$count?></td>
      <td><div class="scrollableq2"><?=$row["name"]?></div></td>
      <td><div class="scrollableq2"><?=$row["email"]?></div></td>
      <td><div class="scrollableq2"><?=$row["address"]?></div></td>
      <td><?=$row["phone"]?></td>
      <td><div class="scrollableq2"><?=$row["queries"]?></div></td>     
      
     <td><form action="code.php" method="post"><button type="submit" class="btn btn-danger" style="height:40px" name="deleteQuery" value="<?=$row['id']?>">Delete</button></form></td>
      </tr>
      <?php
            $count=$count+1;
          }
        }
      ?>
  </table>
   
</div>
 
</div>
<?php
            include "./footerpage.php";
?>