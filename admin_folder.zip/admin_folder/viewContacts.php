<?php
            include "./headerpage.php";
?><?php session_start();
if(empty($_SESSION['id'])):
    header('Location:login.php');
endif;
?>
<?php 
if(isset($_SESSION['status'])){
  
    ?>
    <div class="alert alert-success alert-dismissible" style="width:500px;margin: 0 auto;padding-top:10px;">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Success!!!</strong>  <?php echo $_SESSION['status'];?>
  </div>
    
<?php
unset($_SESSION['status']);

}


?>
<?php
      $con= mysqli_connect("localhost","root","","myproject");
      $query="SELECT * from contact";
      $query_run=mysqli_query($con,$query);
      $row=mysqli_fetch_array($query_run);
    ?>
<div  style="padding-left:2%;padding-right:2%;">
<h2>Shop Contact Details</h2>


<div style="border:2px dashed black;border-radius:25px; padding:20px; margin-bottom:40px; margin-left:10%;margin-right:10%">
<h2 >Contact Number</h2>


<i class="fa fa-phone-alt"> </i><?php echo $row['phone']?><br><?php echo $row['phone2']; ?>
</div>
<div style="border:2px dashed black;border-radius:25px; padding:20px; margin-bottom:40px;margin-top:10px; margin-left:10%;margin-right:10%">
<h2 >Address</h2>


<i class="fa fa-store-alt"> </i><?php echo $row['address']?>
</div>
<div style="border:2px dashed black;border-radius:25px; padding:20px; margin-bottom:40px;margin-top:10px; margin-left:10%;margin-right:10%">
<h2 >Query Description</h2>


<?php echo $row['queryorder_des']?>
</div>
<button style="border-radius:2px;margin-bottom:50px;margin-top:5px; margin-left:10%;margin-right:10%;width:50%"type="button" class="btn btn-info btnEC" style="height:40px" name="btnEC">Edit</button>



</div>


<div class="modal fade" id="myModaledit" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title"> Edit Contact Page Details</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
          <form action="code.php" enctype='multipart/form-data' method="POST">
          
           <br>
           Phone<br>
          <input type="text" name="phone" id="phone" class="form-control" required value="<?php echo $row['phone']?>"> <br> 
          Phone 2<br>
          <input type="text" name="phone2" id="phone2" class="form-control" required value="<?php echo $row['phone2']?>"> <br> 
          Address<br>
          <textarea type="text" name="addr" id="addr" class="form-control" rows="5" cols="70" required><?php echo $row['address']?></textarea> <br> 

          Query Order Description Content<br>
          <textarea type="text" name="qdes" id="qdes" class="form-control" rows="5" cols="70" required><?php echo $row['queryorder_des']?></textarea><br>    
           
            
           <button type="submit" name="editContact" id="editContact" class="btn btn-success">SUBMIT</button>
            
          </form>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal" style="height:40px">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  <script>
  $(document).ready(function(){
    $('.btnEC').on('click',function(){

      $('#myModaledit').modal('show');
      
    });
  });
</script>





<?php
            include "./footerpage.php";
?>