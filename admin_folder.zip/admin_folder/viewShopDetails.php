<?php
            include "./headerpage.php";
?><?php session_start();
if(empty($_SESSION['id'])):
    header('Location:login.php');
endif;
?>
<?php 
if(isset($_SESSION['status'])){
  
    ?>
    <div class="alert alert-success alert-dismissible" style="width:500px;margin: 0 auto;">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Success!!!</strong>  <?php echo $_SESSION['status'];?>
  </div>
    
<?php
unset($_SESSION['status']);

}


?>

<style>
  
@media screen and (max-width: 600px) {
  div.scrollable2 {
    width: 100%;
    height:100%;
    margin: 0;
    padding: 10px;
    overflow: auto;
  
  
  }

}


  </style>
<style>
  div.scrollable {
    width: 100%;
    height: 200px;
    margin: 0;
    padding: 10px;
    overflow: auto;
}
  </style>
<div >
  
  <?php 
if(isset($_SESSION['status'])){
  
    ?>
    <div class="alert alert-success alert-dismissible" style="width:500px;">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Success!</strong>  <?php echo $_SESSION['status'];?>
  </div>
    
<?php
unset($_SESSION['status']);

}


?>
<div class="scrollable2"  style="padding-left:2%;padding-right:2%;">
<h2>Home Page Shop Details</h2>
  
  <table class="table ">
    <thead>
      <tr>
        
        <th class="text-center">Description Title </th>
        <th class="text-center">Description</th>        
        <th class="text-center">Footer Content</th>
        <th class="text-center">Action</th>
        
      </tr>
    </thead>
    <?php
      $con= mysqli_connect("localhost","root","","myproject");
      $query="SELECT * from test ";
      $query_run=mysqli_query($con,$query);
      $row=mysqli_fetch_array($query_run);
    ?>
    <tr>
      
      <td><?=$row["description_title"]?> </td>
      <td style="text-align:justify"><div class=scrollable><?=$row["description"]?></div></td>
      
      <td><?=$row["footer"]?></td>
      <td><button type="button" class="btn btn-primary btn2Edit" style="height:40px" name="btn2edit">Edit</button></td>
    </tr>
    
  </table>
</div>
<br><br>
<div class="row" style="border:2px dashed black;border-radius:25px; padding:20px; margin-bottom:50px; margin-left:10%;margin-right:10%">
  <div class="col-sm-6"><p style="padding-left:40px ;"><?php echo '<img src="data:image;base64,'.base64_encode($row['image']).'"  height="200px" width="200px" alt="..." style="margin-right:20px;">' ?></p></div>
  <div class="col-sm-6"><form method="post" action="code.php" ><input type="file" class="form-control" name="image" style="margin-top:100px" required><br><button type="submit" class="btn btn-info btnIEdit" style="height:40px" name="Iedit">Change Display Image</button></form></div>
</div>
<div class="row" style="border:2px dashed black;border-radius:25px; padding:20px; margin-bottom:50px; margin-left:10%;margin-right:10%">
  <div class="col-sm-4"><p style="padding-left:40px ;">Best Design of Ring<br><?php echo '<img src="data:image;base64,'.base64_encode($row['image_ring']).'"  height="200px" width="200px" alt="..." style="margin-right:20px;">' ?></p></div>
  
  <div class="col-sm-5"><form method="post" action="code.php">
    <div class="scrollable">
    <textarea type="text" name="des_r" id="des_r" rows="8" cols="35" required><?php echo $row['des_ring']?> </textarea>

    </div><br>
    <button type="submit" class="btn btn-info btnRDEdit" style="height:40px" name="editRD">Change Description</button>
  </form></div>
  <div class="col-sm-3"><form method="post" action="code.php" ><input type="file" class="form-control" name="image" style="margin-top:100px" required><br><button type="submit" class="btn btn-info btnIEditr" style="height:40px" name="Redit">Change Image</button></form></div>
</div>


<div class="row" style="border:2px dashed black;border-radius:25px; padding:20px; margin-bottom:50px; margin-left:10%;margin-right:10%">
  <div class="col-sm-4"><p style="padding-left:40px ;">Best Design of Neclace<br><?php echo '<img src="data:image;base64,'.base64_encode($row['image_necklace']).'"  height="200px" width="200px" alt="..." style="margin-right:20px;">' ?></p></div>
  <div class="col-sm-5"><form method="post" action="code.php">
    <div class="scrollable">
    <textarea type="text" name="des_n" id="des_n" rows="8" cols="35" required><?php echo $row['des_necklace']?> </textarea>

    </div><br>
    <button type="submit" class="btn btn-info btnRDEdit" style="height:40px" name="editND">Change Description</button>
  </form></div>
  <div class="col-sm-3"><form method="post" action="code.php" ><input type="file" class="form-control" name="image" style="margin-top:100px" required><br><button type="submit" class="btn btn-info btnIEditn" style="height:40px" name="Nedit">Change Image</button></form></div>
</div>


<div class="row" style="border:2px dashed black;border-radius:25px; padding:20px; margin-bottom:50px; margin-left:10%;margin-right:10%">
  <div class="col-sm-4"><p style="padding-left:40px ;">Best Design of Bangle<br><?php echo '<img src="data:image;base64,'.base64_encode($row['image_bangle']).'"  height="200px" width="200px" alt="..." style="margin-right:20px;">' ?></p></div>
  <div class="col-sm-5"><form method="post" action="code.php">
    <div class="scrollable">
    <textarea type="text" name="des_b" id="des_b" rows="8" cols="35" required><?php echo $row['des_bangle']?> </textarea>

    </div><br>
    <button type="submit" class="btn btn-info btnRDEdit" style="height:40px" name="editBD">Change Description</button>
  </form></div>
  <div class="col-sm-3"><form method="post" action="code.php" ><input type="file" class="form-control" name="image" style="margin-top:100px" required><br><button type="submit" class="btn btn-info btnIEditb" style="height:40px" name="Bedit">Change Image</button></form></div>
</div>
  





  <div class="modal fade" id="myModaledit" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title"> Edit Jewel</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
          <form action="code.php" enctype='multipart/form-data' method="POST">
          
           <br>
           Description_title<br>
          <input type="text" name="d_title" id="d_title" class="form-control" required> <br> 
          Description<br>
          <textarea type="text" name="des" id="des" class="form-control" rows="5" cols="70" required></textarea> <br> 

          Footer Content<br>
          <input type="text" name="footer_content" id="footer_content" class="form-control" required> <br>    
           
            
           <button type="submit" name="editShop" id="editShop" class="btn btn-success">SUBMIT</button>
            
          </form>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal" style="height:40px">Close</button>
        </div>
      </div>
      
    </div>
  </div>

  <script>
  $(document).ready(function(){
    $('.btn2Edit').on('click',function(){

      $('#myModaledit').modal('show');
      $tr=$(this).closest('tr');
      var data=$tr.children("td").map(function(){
        return $(this).text();

      }).get();
      $('#d_title').val(data[0])
      $('#des').val(data[1]);
      $('#footer_content').val(data[2]);
    });
  });
</script>


<?php
            include "./footerpage.php";
?>