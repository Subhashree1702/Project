<?php  
session_start();

$con= mysqli_connect("localhost","root","","myproject");

if(isset($_POST['uploadfile']))
{
    $jname=$_POST['jname'];
    
    $file=addslashes(file_get_contents($_FILES["image"]["tmp_name"]));

    $query="INSERT INTO jewel (name,image) VALUES('$jname','$file')";
    $query_run=mysqli_query($con,$query);

    if($query_run){
        $_SESSION['status']="INSERTED";
        
        header("Location:./index.php");
    }

}
if(isset($_POST['edit'])){
    $j_id=$_POST['edit'];
    $jname=$_POST['jname'];
    
    $file=addslashes(file_get_contents($_FILES["image"]["tmp_name"]));

    
    $query="UPDATE jewel SET name='$jname',image='$file' WHERE  id='$j_id'";
    $query_run=mysqli_query($con,$query);
    if($query_run){
        
        $_SESSION['status']="UPDATED";
        header("Location:./index.php");

    }

  }

  if(isset($_POST['delete'])){
    $j_id=$_POST['delete'];
    
    $query="DELETE FROM jewel WHERE  id='$j_id'";
    $query_run=mysqli_query($con,$query);
    if($query_run){
        $_SESSION['status']="DELETED";
        
        header("Location:./index.php");

    }
    
  }

  
  if(isset($_POST['Iedit'])){
    
    
    $file=addslashes(file_get_contents($_FILES["image"]["tmp_name"]));

    
    $query="UPDATE test SET image='$file' WHERE  id='1'";
    $query_run=mysqli_query($con,$query);
    if($query_run){
        
        $_SESSION['status']="UPDATED";
        header("Location:./viewShopDetails.php");

    }

  }
  if(isset($_POST['Redit'])){
    
    
    $file=addslashes(file_get_contents($_FILES["image"]["tmp_name"]));

    
    $query="UPDATE test SET image_ring='$file' WHERE  id='1'";
    $query_run=mysqli_query($con,$query);
    if($query_run){
        
        $_SESSION['status']="UPDATED";
        header("Location:./viewShopDetails.php");

    }

  }
  if(isset($_POST['Nedit'])){
    
    
    $file=addslashes(file_get_contents($_FILES["image"]["tmp_name"]));

    
    $query="UPDATE test SET image_necklace='$file' WHERE  id='1'";
    $query_run=mysqli_query($con,$query);
    if($query_run){
       
        $_SESSION['status']="UPDATED";
        header("Location:./viewShopDetails.php");

    }

  }
  if(isset($_POST['Bedit'])){
    
    
    $file=addslashes(file_get_contents($_FILES["image"]["tmp_name"]));

    
    $query="UPDATE test SET image_bangle='$file' WHERE  id='1'";
    $query_run=mysqli_query($con,$query);
    if($query_run){
        
        $_SESSION['status']="UPDATED";
        header("Location:./viewShopDetails.php");

    }

  }
  if(isset($_POST['editRD'])){
    
    
    $des=$_POST['des_r'];

    
    $query="UPDATE test SET des_ring='$des' WHERE  id='1'";
    $query_run=mysqli_query($con,$query);
    if($query_run){
        
        $_SESSION['status']="UPDATED";
        header("Location:./viewShopDetails.php");

    }

  }
  if(isset($_POST['editND'])){
    
    
    $des=$_POST['des_n'];

    
    $query="UPDATE test SET des_necklace='$des' WHERE  id='1'";
    $query_run=mysqli_query($con,$query);
    if($query_run){
        
        $_SESSION['status']="UPDATED";
        header("Location:./viewShopDetails.php");

    }

  }
  if(isset($_POST['editBD'])){
    
    
    $des=$_POST['des_b'];

    
    $query="UPDATE test SET des_bangle='$des' WHERE  id='1'";
    $query_run=mysqli_query($con,$query);
    if($query_run){
        
        $_SESSION['status']="UPDATED";
        header("Location:./viewShopDetails.php");

    }

  }
  if(isset($_POST['editShop'])){
    
    $dt=$_POST['d_title'];
    $des=$_POST['des'];
    $ft=$_POST['footer_content'];
    
   

    
    $query="UPDATE test SET description_title='$dt',description='$des',footer='$ft' WHERE  id='1'";
    $query_run=mysqli_query($con,$query);
    if($query_run){
        
        $_SESSION['status']="UPDATED";
        header("Location:./viewShopDetails.php");

    }

  }
  if(isset($_POST['editContact'])){
    
    $ph=$_POST['phone'];
    $ph2=$_POST['phone2'];
    $ad=$_POST['addr'];
    $qd=$_POST['qdes'];
    
   

    
    $query="UPDATE contact SET phone='$ph',address='$ad',queryorder_des='$qd',phone2='$ph2' WHERE  id='1'";
    $query_run=mysqli_query($con,$query);
    if($query_run){
        
        $_SESSION['status']="UPDATED";
        header("Location:./viewContacts.php");

    }

  }
  
  if(isset($_POST['deleteQuery'])){
    $q_id=$_POST['deleteQuery'];
    
    $query="DELETE FROM customer_queries WHERE  id='$q_id'";
    $query_run=mysqli_query($con,$query);
    if($query_run){
        $_SESSION['status']="DELETED";
        header("Location:./viewQueries.php");

    }
    
  }
  if(isset($_POST['uploadAdmin']))
{
    $uname=$_POST['username'];
    $pswd=$_POST['password'];
    
    

    $query="INSERT INTO login (username,password) VALUES('$uname','$pswd')";
    $query_run=mysqli_query($con,$query);

    if($query_run){
        $_SESSION['status']="INSERTED";
        
        header("Location:./viewAdmin.php");
    }

}

  if(isset($_POST['editAdmin'])){
    $a_id=$_POST['editAdmin'];
    $uname=$_POST['username'];
    $pswd=$_POST['password'];
    
    

    
    $query="UPDATE login SET username='$uname',password='$pswd' WHERE  id='$a_id'";
    $query_run=mysqli_query($con,$query);
    if($query_run){
        
        $_SESSION['status']="UPDATED";
        header("Location:./viewAdmin.php");

    }

  }
  if(isset($_POST['deleteAdmin'])){
    $a_id=$_POST['deleteAdmin'];
    
    $query="DELETE FROM login WHERE  id='$a_id'";
    $query_run=mysqli_query($con,$query);
    if($query_run){
        $_SESSION['status']="DELETED";
        header("Location:./viewAdmin.php");

    }
    
  }

  



?>

