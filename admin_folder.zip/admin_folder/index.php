<?php
            include "./headerpage.php";
?>
<?php session_start();
if(empty($_SESSION['id'])):
    header('Location:login.php');
endif;
?>
<?php 
if(isset($_SESSION['status'])){
  
    ?>
    <div class="alert alert-success alert-dismissible" style="width:500px;margin: 0 auto;">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Jewel</strong>  <?php echo $_SESSION['status'];?>
  </div>
    
<?php
unset($_SESSION['status']);

}


?>


<style>
 
@media screen and (max-width: 600px) {
  div.scrollable3 {
    width: 100%;
    height:100%;
    margin: 0;
    padding: 10px;
    overflow: auto;
  
  
  }

}
  </style>
<div >

  
  
  <div class="scrollable3" style="padding-left:2%;padding-right:2%;">
  <h2>Jewels</h2>
  <table class="table table-striped table-hover">
    <thead>
      <tr>
        <th class="text-center">S.No.</th>
        <th class="text-center">Jewel Image</th>
        <th class="text-center">Jewel Name</th> 
        <th class="text-center">Jewel Id</th>       
        <th class="text-center" colspan="2">Action</th>
      </tr>
    </thead>
    <?php
      $conn= mysqli_connect("localhost","root","","myproject");
      $sql="SELECT * from jewel";
      $result=$conn-> query($sql);
      $count=1;
      if ($result-> num_rows > 0){
        while ($row=$result-> fetch_assoc()) {
    ?>
    <tr>
      <td><?=$count?></td>
      <td><?php echo '<img src="data:image;base64,'.base64_encode($row['image']).'"  height="100px" alt="...">' ?></td>
      <td><?=$row["name"]?></td>
      <td><?=$row["id"]?></td>
      
         
      <td><button type="button" class="btn btn-primary btnEdit" style="height:40px" name="btnedit">Edit</button></td>
      <td><form action="code.php" method="post"><button type="submit" class="btn btn-danger" style="height:40px" name="delete" value="<?=$row['id']?>">Delete</button></form></td>
      </tr>
      <?php
            $count=$count+1;
          }
        }
      ?>
  </table>
  <br>
  <button type="button" class="btn btn-secondary " style="height:40px" data-toggle="modal" data-target="#myModal">
    Add Product
  </button>
  </div>
  
  
  
  

  <!-- Trigger the modal with a button -->
  

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">New Product Item</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
          <form action="code.php" enctype='multipart/form-data' method="POST">
          
           <br>
          Jewel name<br>
          <input type="text" name="jname" class="form-control" required> <br>    
           Image<br><input type="file" class="form-control" name="image" required>
           <br>
            
           <button type="submit" name="uploadfile" class="btn btn-success">SUBMIT</button>
            
          </form>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal" style="height:40px">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  <div class="modal fade" id="myModaledit" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title"> Edit Jewel</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
          <form action="code.php" enctype='multipart/form-data' method="POST">
          
           <br>
          Jewel name<br>
          <input type="text" name="jname" id="j_name" class="form-control" required> <br>    
           Image<br><input type="file" class="form-control"  name="image" required>
           <br>
            
           <button type="submit" name="edit" id="edm" class="btn btn-success">SUBMIT</button>
            
          </form>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal" style="height:40px">Close</button>
        </div>
      </div>
      
    </div>
  </div>
<script>
  $(document).ready(function(){
    $('.btnEdit').on('click',function(){

      $('#myModaledit').modal('show');
      $tr=$(this).closest('tr');
      var data=$tr.children("td").map(function(){
        return $(this).text();

      }).get();
      $('#j_name').val(data[2])
      $('#edm').val(data[3]);
    });
  });
</script>
  
</div>

<br><br>

<?php
            include "./footerpage.php";
?>