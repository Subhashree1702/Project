<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
  <title>Login</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
       <link rel="stylesheet" href="./assets/css/style.css"></link>
  <style>
    body {
    
    background: linear-gradient(to right, #ffcc66 0%, #ff99cc 100%)
}


  </style>
</head>
<body>
<script type="text/javascript" src="./assets/js/ajaxWork.js"></script>    
    <script type="text/javascript" src="./assets/js/script.js"></script>
    <script src="https://code.jquery.com/jquery-3.1.1.min.js" ></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" ></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js"></script>
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>


  
  <?php session_start();
if(isset($_SESSION['status'])){
  
    ?>
    <div class="alert alert-warning alert-dismissible" style="width:500px;margin: 0 auto;">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Sorry!!! </strong>  <?php echo $_SESSION['status'];?>
  </div>
    
<?php
unset($_SESSION['status']);

}


?>

   <div >
      <div class="ch" style="border-radius:25px;background-color:white;padding:25px;color:maroon;position: absolute;top: 50%;left: 50%;transform: translate(-50%, -50%); ">
      <h3 style="text-align:center;">Sri Jothi Vigneesh Jewellers</h3>
        <form method="POST" action="log.php">
          
          Username<br>
          <input type="text" name="username" class="form-control"placeholder="username" required><br>
          Password<br>
          <input type="password" name="password" class="form-control"placeholder="password" required><br>
          <button type="submit" class="btn btn-info" name="btnLogin">Login</button>


        </form>
      </div>
      
    </div>


</body>
</html>