



<?php include('header.php'); ?>
<?php include('nav3.php'); ?>

<style>
  .dot{
        height: 18px;
  width: 18px;
  margin-left: 5px;
  margin-right: 5px;
  background-color:#EBA833;
  border-radius: 50%;
  display: inline-block;

    }
    .dot2{
        height: 15px;
  width: 15px;
  margin-left: 5px;
  margin-right: 5px;
  background-color:#EBA833;
  border-radius: 50%;
  display: inline-block;

    }

    h3{
        text-align: center;
        color: maroon;
    }
    .cc2{
        border: 2px solid #EBA833;
        border-radius: 20px;
        height: 200px;
        width:300px;
        text-align: center;
        
        margin-top: 5px;

        
        
        
    }
    .c1{
        color: black;
        font-size: medium;
        margin-top: 30px;
        
        padding: 5px;
    }
    .card{
        width:300px;
        height:250px;
        padding: 10px;
        border-radius: 30px;
    }
    @media screen and (max-width: 990px) {
  .card {
    border:1px solid #EBA833;
     
      width: 200px;
      height:200px;
      border-radius: 30px;
      margin-left:10%;
      margin-top:10px;


  }
  .card-title{
    
    padding-top: 5%;
    padding-left: 5%;
  

  }}
    
    @media screen and (max-width: 600px) {
  .card {
    border:1px solid #EBA833;
     
      width: 300px;
      border-radius: 30px;
      margin-left:10%;
      margin-top:10px;


  }
  .card-title{
    
    padding-top: 5%;
    padding-left: 5%;
  

  }}
  



</style>

<?php
    $con= mysqli_connect("localhost","root","","myproject");

    $query="SELECT * FROM contact where id='1';";
    $query_run=mysqli_query($con,$query);
    $row=mysqli_fetch_array($query_run);
?>
<?php  
session_start();

$con= mysqli_connect("localhost","root","","myproject");
$err=" ";
$msg="";
if(isset($_POST['submit']))
{
    $name=$_POST['name'];
    $phone=$_POST['phone'];
    $mail=$_POST['mail'];
    $address=$_POST['address'];
    
    $yourqueries=$_POST['queries'];
    if(preg_match("/^([0-9]{10})$/",$phone)===false){
        $err="Enter valid phone";
        

    }
    if(filter_var($mail, FILTER_VALIDATE_EMAIL) === false){
      $err="Enter valid email";     
    }
    $query="INSERT INTO customer_queries (name,phone,email,address,queries) VALUES('$name','$phone','$mail','$address','$yourqueries')";
    $query_run=mysqli_query($con,$query);

    if($query_run){
      $msg="your query is received Successfully!";
        
    }
    else{
      $msg="we are unable to recieve your query!";
    }


     

    

}


?>
<h1 style="color:maroon;text-align:center;margin-top:100px"><span class="dot"></span>Contact<span class="dot"></span></h1>
<hr style="border:1px solid #EBA833; background-color:#EBA833; margin-left:25%;margin-right:25%;">
<div class="container-fluid py-1" style="margin-left:5%;margin-right:5%;margin-bottom:10%;">
<div class="row"style="padding-left:5%">

<div class="col-sm-4"  >
    <br>
    <div class="card" style="text-align:justify; align-items:center;border:2px solid #EBA833">                       
                          
            <div class="card-body">
                            
             <h3 class="card-title" >Contact Number:</h3>
             <p class="card-text" style="text-align:center;"><?php echo $row['phone']; ?><br><?php echo $row['phone2']; ?></p>
                            
            </div>
    </div>               
   

</div>
<div class="col-sm-4">
    <br>
    <div class="card" style="text-align:justify; align-items:center;border:2px solid #EBA833">                       
                          
            <div class="card-body">
                            
             <h3 class="card-title" >Address:</h3>
             <p class="card-text" style="text-align:center;"><address><?php echo $row['address']; ?></address></p>
                            
            </div>
    </div>          
    
</div>
<div class="col-sm-4">
    <br>
    <div class="card" style="text-align:justify; align-items:center;border:2px solid #EBA833">                       
                          
            <div class="card-body">
                            
             <h3 class="card-title" >Location:</h3>
             <p class="card-text" style="text-align:center;padding-left:10px" ><iframe  src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15641.262692217615!2d77.4309413!3d11.4571256!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x310d96e586b038ce!2sSri%20Jothi%20Vighnessh%20Jewellers!5e0!3m2!1sen!2sin!4v1658299162266!5m2!1sen!2sin" width="150" height="100" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></p>
                            
            </div>
    </div>          
    


</div>
</div>
<br>

<h2 style="color:maroon;text-align:center;margin-top:8%"><span class="dot2"></span>For Order and Queries<span class="dot2"></span></h2>
<hr style="border:1px solid #EBA833; background-color:#EBA833; margin-left:25%;margin-right:25%;">      
         <p><?php echo $row['queryorder_des']; ?> </p>
         <br><br>
         <div class="row">
        <div class="col-sm-4"></div>
        <div class="col-sm-4 pt-3" style="background-color:white; border-radius: 25px; border:2px solid #EBA833;padding:40px">
            <form  method="POST" >
                
                            NAME:
                       
                            <input  id="name" type="text" class="form-control" name="name" required><br>
                            PHONE:<span style="color:red"><?php echo $err; ?></span>
        
                        
                            <input id="phone" type="tel" class="form-control" name="phone" pattern="[0-9]{10}" required>   <br>                  
                        
        
                       
                            EMAIL ID:<span style="color:red"><?php echo $err; ?></span>
                        
                            <input id="mail" type="email" class="form-control" name="mail" required>     <br>                   
                        
                           
                         
                            ADDRESS:         
        
                       
                            <textarea id="address" type="text" class="form-control" name="address"required rows="3"></textarea><br>
                            YOUR QUERY:
                       
                            <textarea id="queries" type="text" class="form-control" name="queries"required rows="3"></textarea><br>
                        
                            <button type="submit" name="submit" class="btn btn-success">SUBMIT</button>
                        
            </form>
        </div>
        <div class="col-sm-4"></div>
    </div>
    
</div>


<?php include('footer.php'); ?>