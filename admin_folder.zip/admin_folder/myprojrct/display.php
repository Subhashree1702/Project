

<style>
    .button1{
        transition-duration: 0.4s;
         cursor: pointer;
         background-color: black;
         color:white;
    }
    .button1:hover{
        background-color:beige;
        color: #EBA833;
    }
</style>

<div class="container-fluid py-1" style="margin-top:10%; margin-left:5%;margin-right:5%; margin-bottom:10%;">
<div class="row mt-4">

    <div class="col-sm-8"   >
        
        <p style="text-align:justify ; margin-top:50px">a reader will be distracted by the readable content of a page when looking at its layout. The point of using LoremIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem</p>
        <a href="jewellery.php">
        <button class="button button1" style="float:right; border:3px solid #EBA833;  border-radius:30px;padding:10px 30px 10px 30px;font-size:large ">See More</button>
        </a>
        
    </div>
    <div class="col-sm-3" style="padding-left:120px;">
        
           <img src="images/beimg.png" width="250px" height="250px" style="border:20px solid #EBA833;" class="img-circle" alt="ring" >
        
        
        
    </div>
</div>
</div>