<?php include('header.php'); ?>
<?php include('navbar.php'); ?>
<style>
    #backdiv{
        background-image:url("images/banner1.png");
        background-repeat: no-repeat;
        background-attachment: scroll;
        background-size: 100% 100%;
            
        
       
    }
    .button1{
        transition-duration: 0.4s;
         cursor: pointer;
         background-color: black;
         color:white;
    }
    .button1:hover{
        background-color:beige;
        color: #EBA833;
    }
    .dot{
        height: 18px;
  width: 18px;
  margin-left: 5px;
  margin-right: 5px;
  background-color:#EBA833;
  border-radius: 50%;
  display: inline-block;

    }
</style>
<?php
    $con= mysqli_connect("localhost","root","","myproject");

    $query="SELECT * FROM test where id='1'";
    $query_run=mysqli_query($con,$query);
    $row=mysqli_fetch_array($query_run);
?>
<br>
<div class="container-fluid" id="backdiv">
<div class="row" >
    <div class="col-sm-7" style="padding:100px;" >
        <h4 style="color:maroon; font-family:'Courier New', Courier, monospace;text-align: center; font-weight: bolder;"><?php echo $row['description_title']; ?></h4>
        <p style="color:rgb(63, 18, 18);text-align: justify;"><?php echo $row['description']; ?></p>
    </div>
    
    <div class="col-sm-5" style="padding-right:80px;padding-top:80px;padding-bottom: 80px; padding-left:130px; margin-top:5px;">
    <?php echo '<img src="data:image;base64,'.base64_encode($row['image']).'" width="250px" height="200px" alt="...">' ?>
  </div>
</div>
        
    </div>
  </div>
</div>

<br>



<div class="container-fluid py-1" style="margin-top:5%; margin-left:5%;margin-right:5%; margin-bottom:10%;">

<h1 style="text-align:center; color:maroon; font-family:'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;"><span class="dot"></span> Our Best Designs <span class="dot"></span></h1>
<br>
<div class="row mt-4" style="margin-bottom:20px;">

    <div class="col-sm-8" style="padding-left:60px"  >
        
        <p style="text-align:justify ; margin-top:50px"><b>BEST DESIGN OF RING</b><br><?php echo $row['des_ring']; ?></p>
        <a href="jewellery.php">
        <button class="button button1" style="float:right; border:3px solid #EBA833;  border-radius:30px;padding:10px 30px 10px 30px;font-size:large ">See More</button>
        </a>
        
    </div>
    <div class="col-sm-3" style="padding-left:120px;">
    <?php echo '<img src="data:image;base64,'.base64_encode($row['image_ring']).'" width="250px" height="250px" style="border:20px solid #EBA833; padding:2px;" class="img-circle" alt="ring" >' ?>
        
           
        
        
        
    </div>
</div>
<hr style="border:2px solid #EBA833; background-color:#EBA833;">
<div class="row mt-4" style="margin-top:50px;margin-bottom:20px;">

    
    <div class="col-sm-3" style="padding-left:120px">
        
    <?php echo '<img src="data:image;base64,'.base64_encode($row['image_necklace']).'" width="250px" height="250px" style="border:20px solid #EBA833; padding:2px;" class="img-circle" alt="ring" >' ?>
    </div>
    <div class="col-sm-8" style="padding-left:60px">
        
        <p style="text-align:justify ; margin-top:50px"><b>BEST DESIGN OF NECLACE</b><br><?php echo $row['des_necklace']; ?></p>
        <a href="jewellery.php">
        <button class="button button1" style="float:left; border:3px solid #EBA833;  border-radius:30px;padding:10px 30px 10px 30px;font-size:large ">See More</button>
        </a>
        
    </div>

</div>
<hr style="border:2px solid #EBA833; background-color:#EBA833;">
<div class="row mt-4" style="margin-top:50px">

    <div class="col-sm-8" style="padding-left:60px"  >
        
        <p style="text-align:justify ; margin-top:50px"><b>BEST DESIGN OF BANGLE</b><br><?php echo $row['des_bangle']; ?></p>
        <a href="jewellery.php">
        <button class="button button1" style="float:right; border:3px solid #EBA833;  border-radius:30px;padding:10px 30px 10px 30px;font-size:large ">See More</button>
        </a>
        
    </div>
    <div class="col-sm-3" style="padding-left:120px;">
        
    <?php echo '<img src="data:image;base64,'.base64_encode($row['image_bangle']).'" width="250px" height="250px" style="border:20px solid #EBA833; padding:2px;" class="img-circle" alt="ring" >' ?>
        
        
        
    </div>
</div>
</div>
<br>
<br>





   

<?php include('footer.php'); ?>

   
    
