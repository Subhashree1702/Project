<?php
    $con= mysqli_connect("localhost","root","","myproject");

    $query="SELECT * FROM test";
    $query_run=mysqli_query($con,$query);
    $row=mysqli_fetch_array($query_run);
?>


<div style="background-image:url('images/banner2.png');width:auto;height:fit-content; padding-top:10px;padding-bottom:10px;text-align:center;color:maroon"><?php echo $row['footer']; ?></div>
</body>
</html>

