<?php include('header.php'); ?>
<?php include('nav2.php'); ?>
<style>
  .dot{
        height: 18px;
  width: 18px;
  margin-left: 5px;
  margin-right: 5px;
  background-color:#EBA833;
  border-radius: 50%;
  display: inline-block;

    }
    
    @media screen and (max-width: 600px) {
  .card {
    border:1px solid #EBA833;
     
      width: fit-content;
      
      margin-left:20%;
      margin-top:10px;


  }
  .card-title{
    border-top:1px solid #EBA833;
    padding-top: 5%;
    padding-left: 5%;
  

  }}
  
</style>
<?php
    $con= mysqli_connect("localhost","root","","myproject");

    $query="SELECT * FROM jewel";
    $query_run=mysqli_query($con,$query);
    
?>
<h1 style="color:maroon;text-align:center;margin-top:100px"><span class="dot"></span>Jewellery<span class="dot"></span></h1>
<hr style="border:1px solid #EBA833; background-color:#EBA833; margin-left:25%;margin-right:25%;">
<div class="container-fluid py-1" style="margin-top:5%; margin-left:5%;margin-right:5%; margin-bottom:10%;">

   
      
         <div class="row mt-4" >
          <?php $check_jewel=mysqli_num_rows($query_run)>0;
          if($check_jewel)
          {
              while($row=mysqli_fetch_assoc($query_run))
              {
                ?>
                        <div class="col-sm-3 mt-3 mb-3"  style="margin-bottom:50px">
                        <div class="card" style="text-align:justify; align-items:center">
                        <?php echo '<img src="data:image;base64,'.base64_encode($row['image']).'" width="250px" height="250px" alt="...">' ?>
                          
                          <div class="card-body">
                            
                            <h4 class="card-title" ><?php echo $row['name']; ?></h4>
                            <p class="card-text" style="text-align:justify"></p>
                            
                          </div>
                        </div>               
                      </div>
                      
                
                
                
                
                
                <?php
              }


          }


?>
           
               

                
                  </div>
               
                </div>
               
                
               
                
                
 
 



<?php include('footer.php'); ?>