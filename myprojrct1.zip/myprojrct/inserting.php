<?php include('header.php'); ?>
<br>
<?php 
if(isset($_SESSION['status'])){
    ?>
    
    <div class="alert alert-warning">
  <strong>Hey!</strong> <?php echo $_SESSION['status'];?>
  
</div>
<?php
unset($_SESSION['status']);

}


?>

<form action="code.php" method="POST" enctype="multipart/form-data">
<div class="mb-3">

<input type="text" name="jid" class="form-control">
<br>
          DESCRIPTION TITLE<br>
          <input type="text" name="jname" class="form-control">
        </div>
        <div class=" mb-4">
          DESCRIPTION<br><input type="text" class="form-control" name="des" id="des">
        </div>
        <div class=" mb-4">
          image<br><input type="file" class="form-control" name="image" id="des">
        </div>
        <br>
        <button type="submit" name="insert_data" class="btn btn-success">SUBMIT</button>
</form>




<?php include('footer.php'); ?>