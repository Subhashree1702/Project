<?php  
session_start();

$con= mysqli_connect("localhost","root","","myproject");

if(isset($_POST['insert_data']))
{
    $jname=$_POST['jname'];
    $jid=$_POST['jid'];
    $des=$_POST['des'];
    $file=addslashes(file_get_contents($_FILES["image"]["tmp_name"]));

    $query="INSERT INTO test (id,description_title,description,image) VALUES('$jid','$jname','$des','$file')";
    $query_run=mysqli_query($con,$query);

    if($query_run){
        $_SESSION['status']="INSERTED";
        header("Location:inserting.php");
    }

}


?>